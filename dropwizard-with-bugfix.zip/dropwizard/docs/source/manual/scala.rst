.. _manual-scala:

##################
Dropwizard & Scala
##################

.. highlight:: text

.. rubric:: The ``dropwizard-scala`` module is now maintained and documented `elsewhere <https://github.com/datasift/dropwizard-scala>`_.

The ``metrics-scala`` module is maintained `here <https://github.com/erikvanoosten/metrics-scala>`_.
