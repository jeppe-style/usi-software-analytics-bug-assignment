.. _about-sponsors:

########
Sponsors
########

Dropwizard is generously supported by some companies with licenses and free accounts for their products.


JetBrains
=========

.. image:: jetbrains.png

`JetBrains <https://www.jetbrains.com/>`__ supports our open source project by sponsoring some `All Products Packs <https://www.jetbrains.com/products.html>`__ within their `Free Open Source License <https://www.jetbrains.com/buy/opensource/>`__ program.
