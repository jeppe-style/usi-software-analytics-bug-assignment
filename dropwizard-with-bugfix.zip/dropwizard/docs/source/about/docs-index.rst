.. _docs-index:

##############
Other Versions
##############

- `1.0.4 <http://dropwizard.github.io/dropwizard/1.0.4/docs>`_
- `1.0.3 <http://dropwizard.github.io/dropwizard/1.0.3/docs>`_
- `1.0.2 <http://dropwizard.github.io/dropwizard/1.0.2/docs>`_
- `1.0.1 <http://dropwizard.github.io/dropwizard/1.0.1/docs>`_
- `1.0.0 <http://dropwizard.github.io/dropwizard/1.0.0/docs>`_
- `0.9.0 <http://dropwizard.github.io/dropwizard/0.9.0/docs>`_
- `0.8.4 <http://dropwizard.github.io/dropwizard/0.8.4/docs>`_
- `0.8.2 <http://dropwizard.github.io/dropwizard/0.8.2/docs>`_
- `0.8.1 <http://dropwizard.github.io/dropwizard/0.8.1/docs>`_
- `0.8.0 <http://dropwizard.github.io/dropwizard/0.8.0/docs>`_
- `0.7.1 <http://dropwizard.github.io/dropwizard/0.7.1/docs>`_
- `0.6.2 <http://dropwizard.github.io/dropwizard/0.6.2>`_

