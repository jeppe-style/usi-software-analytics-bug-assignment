.. title:: About

.. _about:

################
About Dropwizard
################

.. toctree::

    contributors
    sponsors
    faq
    release-notes
    security
    todos
