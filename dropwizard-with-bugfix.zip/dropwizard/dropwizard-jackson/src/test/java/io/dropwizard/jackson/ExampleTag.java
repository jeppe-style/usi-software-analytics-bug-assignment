package io.dropwizard.jackson;

public interface ExampleTag {
}
