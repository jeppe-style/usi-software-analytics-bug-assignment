package io.dropwizard.jackson;

import com.fasterxml.jackson.annotation.JsonTypeName;

@JsonTypeName("b")
public class ImplB implements ExampleSPI {
}
