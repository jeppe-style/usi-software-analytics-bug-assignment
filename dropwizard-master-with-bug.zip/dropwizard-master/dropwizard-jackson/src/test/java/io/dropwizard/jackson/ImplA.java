package io.dropwizard.jackson;

import com.fasterxml.jackson.annotation.JsonTypeName;

@JsonTypeName("a")
public class ImplA implements ExampleSPI {
}
