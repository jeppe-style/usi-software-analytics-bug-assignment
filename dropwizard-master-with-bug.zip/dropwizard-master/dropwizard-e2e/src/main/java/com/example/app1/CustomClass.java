package com.example.app1;

public class CustomClass {
}
